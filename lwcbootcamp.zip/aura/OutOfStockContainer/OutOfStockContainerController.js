({
    doInit : function(component, event, helper) {
        helper.getTitles(component, event, helper);
    }
})
