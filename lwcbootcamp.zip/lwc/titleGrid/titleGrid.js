import { LightningElement, api } from 'lwc';

export default class TitleGrid extends LightningElement {

    @api titles;

}