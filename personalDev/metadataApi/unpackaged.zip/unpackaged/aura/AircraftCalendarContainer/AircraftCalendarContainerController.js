({
	retrieveCalendarData : function(component, event, helper) {
		helper.loadCalendarData(component, event, helper);
	}
})