({
	checkZoo : function(component, event, helper) {
		var a = component.get("v.zoo");
		console.log(a);
        var err = component.get("v.targetError");
        console.log(err);
    }
})