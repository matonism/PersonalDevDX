({
     handleInit: function (component, event, helper) {
          helper.initHelper(component, event, helper);
     }
})