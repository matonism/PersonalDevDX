({
	displayCurrentTime : function(component, event, helper) {
		helper.getCoordinatesForLocation(component);
	}
})