({
	transferAnimal : function(component, event, helper) {
		helper.transferAnimal(component, event, helper);
	},
})