({
	triggerLocationEvent : function(component, event, helper) {
		helper.triggerLocationEvent(component);
	}
})