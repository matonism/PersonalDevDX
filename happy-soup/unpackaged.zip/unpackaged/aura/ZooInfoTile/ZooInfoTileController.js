({
	doInit : function(component, event, helper) {
		helper.retrieveAnimalWithZooInfo(component, event, helper);
	}
})