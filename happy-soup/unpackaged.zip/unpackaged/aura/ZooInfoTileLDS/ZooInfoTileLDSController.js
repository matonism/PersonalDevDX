({
	checkAnimal : function(component, event, helper) {
		var a = component.get("v.animal");
		console.log(a);
    }
})