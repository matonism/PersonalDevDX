({
	doInit : function(component, event, helper){
		helper.printToConsole(component);
	},
	navigateToContactsPage : function(component, event, helper) {
		helper.navigateToContactsPage(component);
	},

	navigateToCalloutPage : function(component, event, helper){
		helper.navigateToCalloutPage(component);
	}
})